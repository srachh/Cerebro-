//
//  DTFocusBorder.h
//  FN3
//
//  Created by David Jablonski on 4/30/12.
//  Copyright (c) 2012 Client Resources Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DTBorder.h"

@interface DTFocusBorder : NSObject <DTBorder>

@end
