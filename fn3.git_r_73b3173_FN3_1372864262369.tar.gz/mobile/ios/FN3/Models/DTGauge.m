//
//  DTGauge.m
//  FN3
//
//  Created by David Jablonski on 5/9/12.
//  Copyright (c) 2012 Client Resources Inc. All rights reserved.
//

#import "DTGauge.h"
#import "DTPumpStation.h"


@implementation DTGauge

@dynamic title;
@dynamic min;
@dynamic max;
@dynamic value;
@dynamic pumpStation;
@dynamic colors;
@dynamic markers;

@end
