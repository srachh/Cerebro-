//
//  DTConfigurationDirection.m
//  FieldNET
//
//  Created by Kevin on 9/10/12.
//  Copyright (c) 2012 Client Resources Inc. All rights reserved.
//

#import "DTConfigurationDirection.h"
#import "DTConfiguration.h"


@implementation DTConfigurationDirection

@dynamic name;
@dynamic order;
@dynamic value;
@dynamic configuration;

@end
