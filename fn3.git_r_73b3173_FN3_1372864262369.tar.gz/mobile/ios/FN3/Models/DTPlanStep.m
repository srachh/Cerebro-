//
//  DTPlanStep.m
//  FieldNET
//
//  Created by David Jablonski on 9/4/12.
//  Copyright (c) 2012 Client Resources Inc. All rights reserved.
//

#import "DTPlanStep.h"
#import "DTPlan.h"


@implementation DTPlanStep

@dynamic order;
@dynamic name;
@dynamic value;
@dynamic plan;

@end
