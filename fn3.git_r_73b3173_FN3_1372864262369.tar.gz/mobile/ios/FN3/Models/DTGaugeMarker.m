//
//  DTGaugeMarker.m
//  FN3
//
//  Created by David Jablonski on 5/9/12.
//  Copyright (c) 2012 Client Resources Inc. All rights reserved.
//

#import "DTGaugeMarker.h"
#import "DTGauge.h"


@implementation DTGaugeMarker

@dynamic value;
@dynamic order;
@dynamic fillColor;
@dynamic label;
@dynamic gauge;

@end
