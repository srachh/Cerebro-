//
//  DTGaugeColor.m
//  FN3
//
//  Created by David Jablonski on 5/9/12.
//  Copyright (c) 2012 Client Resources Inc. All rights reserved.
//

#import "DTGaugeColor.h"
#import "DTGauge.h"


@implementation DTGaugeColor

@dynamic color;
@dynamic min;
@dynamic max;
@dynamic order;
@dynamic gauge;

@end
