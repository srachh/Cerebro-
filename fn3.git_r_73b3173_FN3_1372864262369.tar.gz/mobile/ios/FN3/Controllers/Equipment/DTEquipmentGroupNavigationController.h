//
//  DTEquipmentNavigationController.h
//  FN3
//
//  Created by David Jablonski on 3/7/12.
//  Copyright (c) 2012 Client Resources Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DTEquipmentGroupNavigationController : UINavigationController {
    BOOL hasLoadedBefore;
}

@end
