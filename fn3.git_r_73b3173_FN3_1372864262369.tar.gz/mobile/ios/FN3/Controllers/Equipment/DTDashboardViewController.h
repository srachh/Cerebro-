//
//  DTDashboardViewController.h
//  FN3
//
//  Created by David Jablonski on 4/16/12.
//  Copyright (c) 2012 Client Resources Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol DTDashboardViewController <NSObject>

@property (nonatomic, retain) NSNumber *equipmentId;

@end
