//
//  CriMapOverlayView.h
//  FN3
//
//  Created by David Jablonski on 5/7/12.
//  Copyright (c) 2012 Client Resources Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>

@interface DTEquipmentOverlayView : MKOverlayView

@end
