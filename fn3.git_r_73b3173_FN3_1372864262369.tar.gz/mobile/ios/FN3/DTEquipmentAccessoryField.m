//
//  DTEquipmentAccessoryField.m
//  FieldNET
//
//  Created by Loren Davelaar on 1/8/13.
//  Copyright (c) 2013 Client Resources Inc. All rights reserved.
//

#import "DTEquipmentAccessoryField.h"
#import "DTEquipment.h"


@implementation DTEquipmentAccessoryField

@dynamic name;
@dynamic order;
@dynamic value;
@dynamic equipment;

@end
