//
//  main.m
//  FN3
//
//  Created by David Jablonski on 2/21/12.
//  Copyright (c) 2012 Client Resources Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DTAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([DTAppDelegate class]));
    }
}
