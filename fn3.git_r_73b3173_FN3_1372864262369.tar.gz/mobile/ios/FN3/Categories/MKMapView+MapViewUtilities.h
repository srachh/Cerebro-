//
//  MKMapView+MapViewUtilities.h
//  FN3
//
//  Created by Hasani Hunter on 4/16/12.
//  Copyright (c) 2012 Client Resources Inc. All rights reserved.
//

#import <MapKit/MapKit.h>

@interface MKMapView (MapViewUtilities)

-(NSInteger)zoomLevel;

@end
