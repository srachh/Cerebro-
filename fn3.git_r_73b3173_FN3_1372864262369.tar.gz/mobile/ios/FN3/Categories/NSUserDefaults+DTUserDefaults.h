//
//  NSUserDefaults+DTUserDefaults.h
//  FN3
//
//  Created by David Jablonski on 3/30/12.
//  Copyright (c) 2012 Client Resources Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSUserDefaults (DTUserDefaults)

- (NSString *)deviceIdentifier;

@end
